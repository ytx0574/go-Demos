create
    definer = root@`%` function rand_string(n int) returns varchar(255)
begin
    declare char_str varchar(100) default 'jiojfsiojiofwjiojoio223-0i544646546540-jvoxjoifj0932u9uvklvklf;a565456343f';
    declare return_str varchar(255) default '';
    declare i int default 0;
    while i < n do
        set return_str = concat(return_str, substring(char_str, floor(1 + rand() * 54), 1));
        set i = i + 1;
    end while;
    return return_str;
end;

