create
    definer = root@`%` procedure insert_emp(IN start int(10), IN max_num int(10))
begin
    declare i int default  0;
    set autocommit = 0;
    repeat
        set i = i + 1;
        insert into emp(empno, ename, job, mgr, hiredata, sal, comm, deptno) values (start+i, rand_string(11), 'sex', 0001, curdate(), 200, 20, rand_num());
    until i = max_num  end repeat;
    commit ;
end;

